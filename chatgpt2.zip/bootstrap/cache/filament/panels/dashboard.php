<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.dashboard.resources.order-resource.pages.list-orders' => 'App\\Filament\\Dashboard\\Resources\\OrderResource\\Pages\\ListOrders',
    'app.filament.dashboard.resources.order-resource.pages.view-order' => 'App\\Filament\\Dashboard\\Resources\\OrderResource\\Pages\\ViewOrder',
    'app.filament.dashboard.resources.subscription-resource.pages.add-discount' => 'App\\Filament\\Dashboard\\Resources\\SubscriptionResource\\Pages\\AddDiscount',
    'app.filament.dashboard.resources.subscription-resource.pages.cancel-subscription' => 'App\\Filament\\Dashboard\\Resources\\SubscriptionResource\\Pages\\CancelSubscription',
    'app.filament.dashboard.resources.subscription-resource.pages.change-subscription-plan' => 'App\\Filament\\Dashboard\\Resources\\SubscriptionResource\\Pages\\ChangeSubscriptionPlan',
    'app.filament.dashboard.resources.subscription-resource.pages.confirm-cancel-subscription' => 'App\\Filament\\Dashboard\\Resources\\SubscriptionResource\\Pages\\ConfirmCancelSubscription',
    'app.filament.dashboard.resources.subscription-resource.pages.list-subscriptions' => 'App\\Filament\\Dashboard\\Resources\\SubscriptionResource\\Pages\\ListSubscriptions',
    'app.filament.dashboard.resources.subscription-resource.pages.payment-providers.paddle.paddle-update-payment-details' => 'App\\Filament\\Dashboard\\Resources\\SubscriptionResource\\Pages\\PaymentProviders\\Paddle\\PaddleUpdatePaymentDetails',
    'app.filament.dashboard.resources.subscription-resource.pages.view-subscription' => 'App\\Filament\\Dashboard\\Resources\\SubscriptionResource\\Pages\\ViewSubscription',
    'app.filament.dashboard.resources.transaction-resource.pages.list-transactions' => 'App\\Filament\\Dashboard\\Resources\\TransactionResource\\Pages\\ListTransactions',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'jeffgreco13.filament-breezy.pages.my-profile-page' => 'Jeffgreco13\\FilamentBreezy\\Pages\\MyProfilePage',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
    1 => 'Jeffgreco13\\FilamentBreezy\\Pages\\MyProfilePage',
  ),
  'pageDirectories' => 
  array (
    0 => '/home/LVL3o5RayLoWdEWM/chatgpt2/public_html/saas/app/Filament/Dashboard/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Dashboard\\Pages',
  ),
  'resources' => 
  array (
    '/home/LVL3o5RayLoWdEWM/chatgpt2/public_html/saas/app/Filament/Dashboard/Resources/OrderResource.php' => 'App\\Filament\\Dashboard\\Resources\\OrderResource',
    '/home/LVL3o5RayLoWdEWM/chatgpt2/public_html/saas/app/Filament/Dashboard/Resources/SubscriptionResource.php' => 'App\\Filament\\Dashboard\\Resources\\SubscriptionResource',
    '/home/LVL3o5RayLoWdEWM/chatgpt2/public_html/saas/app/Filament/Dashboard/Resources/TransactionResource.php' => 'App\\Filament\\Dashboard\\Resources\\TransactionResource',
  ),
  'resourceDirectories' => 
  array (
    0 => '/home/LVL3o5RayLoWdEWM/chatgpt2/public_html/saas/app/Filament/Dashboard/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Dashboard\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => '/home/LVL3o5RayLoWdEWM/chatgpt2/public_html/saas/app/Filament/Dashboard/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Dashboard\\Widgets',
  ),
);