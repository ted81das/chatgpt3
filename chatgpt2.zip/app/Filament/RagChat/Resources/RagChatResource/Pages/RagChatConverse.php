<?php

namespace App\Filament\RagChat\Resources\RagChatResource\Pages;

use App\Filament\RagChat\Resources\RagChatResource;
use Filament\Resources\Pages\Page;
use App\Models\Conversation;
use App\Models\Document;
use Filament\Resources\Pages\Page;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Forms\Form;
use Illuminate\Contracts\View\View;
use Livewire\Component;
use LLPhant\Chat\OpenAIChat;
use LLPhant\Embeddings\EmbeddingGenerator\OpenAI\OpenAIADA002EmbeddingGenerator;
use LLPhant\Embeddings\VectorStores\Qdrant\QdrantVectorStore;
use LLPhant\Query\SemanticSearch\QuestionAnswering;
use Qdrant\Config;





class RagChatConverse extends Page
{
    protected static string $resource = RagChatResource::class;

    protected static string $view = 'filament.rag-chat.resources.rag-chat-resource.pages.rag-chat-converse';
use InteractsWithForms;

    public ?array $data = [];
    public $messages = [];
    public $streamingResponse = '';

    protected $queryString = [
        'data.vector_store' => ['except' => ''],
        'data.document' => ['except' => ''],
        'data.conversation' => ['except' => ''],
    ];

    public function mount(): void
    {
        $this->form->fill();
    }

    public function form(Form $form): Form
    {
        return $form
            ->schema([
                Select::make('vector_store')
                    ->label('Vector Store Collection')
                    ->options($this->getVectorStoreOptions())
                    ->reactive()
                    ->afterStateUpdated(fn (callable $set) => $set('document', null)),
                Select::make('document')
                    ->label('Document')
                    ->options(fn (callable $get) => $this->getDocumentOptions($get('vector_store')))
                    ->visible(fn (callable $get) => filled($get('vector_store'))),
                Select::make('conversation')
                    ->label('Past Conversation')
                    ->options(fn () => $this->getConversationOptions())
                    ->placeholder('Start a new conversation'),
                Textarea::make('query')
                    ->label('Your message')
                    ->required(),
            ]);
    }

    public function submit()
    {
        $data = $this->form->getState();

        $conversation = Conversation::find($data['conversation']);
        if (!$conversation) {
            $conversation = Conversation::create([
                'title' => 'New Conversation',
                'user_id' => auth()->id(),
            ]);
        }

        $this->messages[] = ['role' => 'user', 'content' => $data['query']];

        $config = new Config(env('QDRANT_HOST'));
        $config->setApiKey(env('QDRANT_API_KEY'));
        $vectorStore = new QdrantVectorStore($config, $data['vector_store']);
        $embeddingGenerator = new OpenAIADA002EmbeddingGenerator();
        $qa = new QuestionAnswering(
            $vectorStore,
            $embeddingGenerator,
            new OpenAIChat()
        );

        $stream = $qa->answerQuestionStream($data['query']);

        $this->messages[] = ['role' => 'assistant', 'content' => ''];
        $index = count($this->messages) - 1;

        foreach ($stream as $response) {
            $this->messages[$index]['content'] .= $response->choices[0]->delta->content;
            $this->streamingResponse .= $response->choices[0]->delta->content;
            $this->dispatchBrowserEvent('newChatContent', ['content' => $this->streamingResponse]);
        }

        $conversation->messages()->create([
            'content' => $data['query'],
            'role' => 'user',
        ]);

        $conversation->messages()->create([
            'content' => $this->messages[$index]['content'],
            'role' => 'assistant',
        ]);

        $this->streamingResponse = '';
        $this->form->fill(['query' => '']);
    }

    public function render(): View
    {
        return view('filament.resources.rag-chat-resource.pages.rag-chat');
    }

    private function getVectorStoreOptions(): array
    {
        // Implement this method to return a list of vector store collections
        // that the current user has access to
        return auth()->user()->vectorStores()->pluck('name', 'id')->toArray();
    }

    private function getDocumentOptions(string $vectorStoreId): array
    {
        // Implement this method to return a list of documents in the selected vector store
        // that the current user has access to
        return Document::where('vector_store_id', $vectorStoreId)
            ->whereBelongsTo(auth()->user())
            ->pluck('title', 'id')
            ->toArray();
    }

    private function getConversationOptions(): array
    {
        return Conversation::whereBelongsTo(auth()->user())
            ->pluck('title', 'id')
            ->toArray();
    }




}
