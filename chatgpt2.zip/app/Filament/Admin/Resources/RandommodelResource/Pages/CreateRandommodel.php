<?php

namespace App\Filament\Admin\Resources\RandommodelResource\Pages;

use App\Filament\Admin\Resources\RandommodelResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRandommodel extends CreateRecord
{
    protected static string $resource = RandommodelResource::class;
}
