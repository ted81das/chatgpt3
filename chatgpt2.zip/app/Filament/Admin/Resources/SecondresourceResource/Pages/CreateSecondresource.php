<?php

namespace App\Filament\Admin\Resources\SecondresourceResource\Pages;

use App\Filament\Admin\Resources\SecondresourceResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSecondresource extends CreateRecord
{
    protected static string $resource = SecondresourceResource::class;
}
