<?php

namespace App\Filament\Admin\Resources\TransactionResource\Pages;

use App\Filament\Admin\Resources\TransactionResource;
use Filament\Resources\Pages\ViewRecord;

class ViewTranscription extends ViewRecord
{
    protected static string $resource = TransactionResource::class;

}
