<?php

namespace App\Filament\Admin\Resources\RoadmapItemResource\Pages;

use App\Filament\Admin\Resources\RoadmapItemResource;
use Filament\Resources\Pages\CreateRecord;

class CreateRoadmapItem extends CreateRecord
{
    protected static string $resource = RoadmapItemResource::class;
}
