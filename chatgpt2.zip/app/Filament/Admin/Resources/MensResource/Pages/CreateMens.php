<?php

namespace App\Filament\Admin\Resources\MensResource\Pages;

use App\Filament\Admin\Resources\MensResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMens extends CreateRecord
{
    protected static string $resource = MensResource::class;
}
