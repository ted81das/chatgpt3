<?php

namespace App\Models;

use Mpociot\Versionable\Version;

class SubscriptionVersion extends Version
{
    public $table = 'subscription_versions';
}
