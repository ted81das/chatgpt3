<?php

namespace App\Livewire\Filament;

class GoogleSettings extends OauthProviderSettings
{
    protected string $slug = 'google';
}
