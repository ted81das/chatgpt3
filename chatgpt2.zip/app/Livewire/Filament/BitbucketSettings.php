<?php

namespace App\Livewire\Filament;

class BitbucketSettings extends OauthProviderSettings
{
    protected string $slug = 'bitbucket';
}
