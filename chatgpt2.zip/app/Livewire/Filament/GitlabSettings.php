<?php

namespace App\Livewire\Filament;

class GitlabSettings extends OauthProviderSettings
{
    protected string $slug = 'gitlab';
}
