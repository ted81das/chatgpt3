<?php

namespace App\Livewire\Filament;

use Livewire\Component;

class GithubSettings extends OauthProviderSettings
{
    protected string $slug = 'github';
}
