<?php

namespace App\Livewire\Filament;

use Livewire\Component;

class FacebookSettings extends OauthProviderSettings
{
    protected string $slug = 'facebook';
}
