<?php

namespace App\Constants;

class PaddleConstants
{
    public const DISCOUNT_TYPE_PERCENTAGE = 'percentage';
    public const DISCOUNT_TYPE_FLAT = 'flat';
}
