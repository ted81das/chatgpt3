<?php

namespace App\Constants;

enum RoadmapItemType: string
{
    case FEATURE = 'feature';
    case BUG = 'bug';
}
