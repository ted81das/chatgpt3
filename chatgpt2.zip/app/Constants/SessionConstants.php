<?php

namespace App\Constants;

class SessionConstants
{
    public const SUBSCRIPTION_CHECKOUT_DTO = 'subscriptionCheckoutDto';
    public const CART_DTO = 'cartDto';
}
