<?php

namespace App\Dto;

class CartItemDto
{
    public ?string $productId = null;
    public int $quantity = 1;
}
